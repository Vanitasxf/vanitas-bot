#### NO MORE UPDATES IN BOSCO ...COMING WITH A NEW BOT SOON🙂💖
#### HOW TO DEPLOY ?? [` CLICK HERE TO WATCH TUTORIAL ✨`](https://youtu.be/ZJQ50wYh7dc) 


<div align="center">
</p>


<div align="center">
<img src="media/boscoimg.jpg" alt="Pepe" width="170" />

# vanitas Bot
<p align="center">
 <a href="https://github.com/pepesir"><img title="Author" src="https://img.shields.io/badge/OWNER-h?color=black&style=for-the-badge&logo=github"></a>  <a href="https://Wa.me/+917736622139?text=Hello%20P3P3%20Bro🌝...fen%20boi%20aan😌💝"><img title="Author" src="https://img.shields.io/badge/Author P3P3 Sir-h?color=black&style=for-the-badge&logo=whatsapp"></a>
<p align="center">
<a href="https://chat.whatsapp.com/BzhyWkAEU0t8oVl3s8p94m"><img title="Author" src="https://img.shields.io/badge/WHATSAPP GROUP-h?color=black&style=for-the-badge&logo=whatsapp"></a>    <a href="https://youtube.com/channel/UCVJ9029PQ-gJBtFQZZ3AJuA"><img title="Author" src="https://img.shields.io/badge/YT PEPE SIR-h?color=black&style=for-the-badge&logo=youtube"></a>
</p>


> Bosco Bot is a multipurpose WhatsApp bot using Adiwajshing-Baileys library!
>
>

<p align="center">
  <a href="https://github.com/pepesir/Bosco#requirements">Requirements</a> •
  <a href="https://github.com/pepesir/Bosco#simple-method">Installation</a> •
  <a href="https://github.com/pepesir/Bosco#thanks-to">Thanks to</a>
</p>
</div>


---

### `SIMPLE METHOD`
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@pepesir/PEPE-SIR-Qr-code?v=1) 


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/pepesir/Bosco/)

### `ADD BUILDPACK`

```
Heroku/nodejs
```
```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
```
https://github.com/DuckyTeam/heroku-buildpack-imagemagick
```

### `FOR TERMUX`

* Yeah , It's now available for termux
* First fork this repo and change session in <a href="https://github.com/pepesir/Bosco/blob/master/Denis.json">Denis.json</a> ,Then follow these commands ✅
* NOTE : U HAVE TO CLONE YOUR FORKED REPO , NOT MINE REPO !!



```
termux-setup-storage
```
```
pkg install git
```
```
pkg install bash
```
```
git clone https://github.com/pepesir/Bosco.git 
```
```
cd Bosco
```
```
bash install.sh
```
```
npm start
```

### `REQUIREMENTS`
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases) (for sticker command)
* [Libwebp](https://developers.google.com/speed/webp/download) (for sticker wm)
* Any text editor


### `⚠ WARNING ⚠`

```
By using bc ,tobc or any other Commands, Your WhatsApp account may be banned.
Pepe Sir or we are not responsible for your account, 
This bot is intended for the purpose of having fun with some fun commands 
and group management with some helpfull commands.

If  you ended up spamming groups, getting reported left and right, 
and you ended up in being fight with WhatsApp
and at the end WhatsApp Team deleted your account. DON'T BLAME US.

No personal support will be provided / We won't spoon feed you. 
If you need help
you can contact us 
```

### `THANKS TO`
* 𝙳𝙴𝙽𝙸𝚂 𝚂𝙸𝚁
* [`𝙺𝚁𝙸𝚉 𝚂𝙸𝚁`](https://github.com/KANNANSIR)
* [`𝙿𝙴𝙿𝙴 𝚂𝙸𝚁`](https://github.com/pepesir)
* [`𝚃𝙰𝚄𝚁𝚄𝚂`](https://github.com/I-AM-MUHAMMED)
* [`𝙰𝙲𝙷𝚄 𝚂𝙸𝚁`](https://github.com/ACHUSIR8)
* [`𝙱𝙰𝙸𝙻𝙴𝚈𝚂`](https://github.com/adiwajshing/Baileys)


