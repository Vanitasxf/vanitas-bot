module.exports.mess = {
	        wait: '*إنتضر*',
			success: '*تم*',
			wrongFormat: '*Format Is Wrong Retry..!*',
			error: {
				api: '*خطأ*',
				stick: '*هادا ليس ستيكر :v*',
				Iv: '*لا يوجد رابط😐*'
			},
			only: {
				group: '*هادا الأمر يعمل في المجموعات فقط.*',
				admin: '*هاد الأمر للمشرفين فقط*',
				premium: '*هادا الأمر للمميزين*',
				owner: '*هادا الأمر للمطور فقط*',
				Badmin: '*This command is only for bots when you are an admin!!*',
			}
		}