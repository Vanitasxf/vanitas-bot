exports.gameMenu = (prefix) => {
    return `
╔════الألعاب══════❥︎
╠➤ ${prefix}slot
╠➤ ${prefix}limitgame
╠➤ ${prefix}gelud @tag
╠➤ ${prefix}tictactoe @tag
╠➤ ${prefix}siapaaku
╠➤ ${prefix}family100
╠➤ ${prefix}kuismath
╠➤ ${prefix}asahotak
╠➤ ${prefix}tebaklirik
╠➤ ${prefix}tebaklagu
╠➤ ${prefix}tebakkata
╠➤ ${prefix}susunkata
╠➤ ${prefix}kimiakuis
╠➤ ${prefix}caklontong
╠➤ ${prefix}tebakjenaka
╠➤ ${prefix}tebakanime
╠➤ ${prefix}tebaktebakan
╠➤ ${prefix}tebakgambar
╠➤ ${prefix}tebakbendera
╠➤ ${prefix}suit *batu/kertas/gunting*
╚════════════════❥︎
`

exports.otherMenu = (prefix) => {
    return `
╔════أخرى══════❥︎
╠➤ ${prefix}brainly *query*
╠➤ ${prefix}shopee *product*
╠➤ ${prefix}playstore *query*
╠➤ ${prefix}ssweb *query*
╠➤ ${prefix}google *query*
╠➤ ${prefix}image *query*
╠➤ ${prefix}pinterest *query*
╠➤ ${prefix}nulis *teks*
╠➤ ${prefix}iguser *ussername*
╠➤ ${prefix}igstalk *username*
╠➤ ${prefix}githubstalk *username*
╠➤ ${prefix}tiktokstalk *ussername*
╠➤ ${prefix}img2url *reply foto*
╠➤ ${prefix}ytsearch *query*
╚════════════════❥︎
`
}
exports.stickerMenu = (prefix) => {
    return `
╔════الستيكرات══════❥︎
╠➤ ${prefix}dadu
╠➤ ${prefix}doge
╠➤ ${prefix}toimg
╠➤ ${prefix}patrick
╠➤ ${prefix}garwgura
╠➤ ${prefix}ttg *teks*
╠➤ ${prefix}attp *teks*
╠➤ ${prefix}stickeranime
╠➤ ${prefix}semoji *emoji*
╠➤ ${prefix}sticker *reply foto/video*
╠➤ ${prefix}smeme *teks|teks*
╠➤ ${prefix}swm *pack|author*
╠➤ ${prefix}take *pack|author* 
╠➤ ${prefix}tovideo *reply sgif*
╚════════════════❥︎
`
}
exports.wibuMenu = (prefix) => {
    return `
╔════أنمي...══════❥︎
╠➤ ${prefix}loli
╠➤ ${prefix}manga
╠➤ ${prefix}anime 
╠➤ ${prefix}lolivideo
╠➤ ${prefix}husbu
╠➤ ${prefix}waifu
╠➤ ${prefix}neko
╠➤ ${prefix}kanna
╠➤ ${prefix}sagiri
╠➤ ${prefix}hentai
╠➤ ${prefix}wallnime
╠➤ ${prefix}storyanime
╠➤ ${prefix}kusonime
╠➤ ${prefix}megumin
╠➤ ${prefix}nakanomiku
╠➤ ${prefix}nakanonino
╠➤ ${prefix}nakanoitsuki
╠➤ ${prefix}otakudesu
╠➤ ${prefix}doujindesu
╠➤ ${prefix}otakuongoing
╠➤ ${prefix}nhentai *code*
╠➤ ${prefix}nekopoi *link*
╠➤ ${prefix}nekopoi3d
╠➤ ${prefix}nekopoicosplay
╠➤ ${prefix}cosplayanime
╠➤ ${prefix}nekopoisearch
╚════════════════❥︎
`
}
exports.ownerMenu = (prefix) => {
    return `
╔════المطور══════❥︎
╠➤ ${prefix}bc *teks*
╠➤ ${prefix}term
╠➤ ${prefix}eval
╠➤ ${prefix}reset
╠➤ ${prefix}clearall
╠➤ ${prefix}join *link gc*
╠➤ ${prefix}shutdown
╠➤ ${prefix}getquoted
╠➤ ${prefix}addupdate *fiturnya*
╠➤ ${prefix}exif *nama|author*
╠➤ ${prefix}sewa add/del *waktunya*
╠➤ ${prefix}premium add @tag|nomor
╠➤ ${prefix}premium del @tag|nomor
╚════════════════❥︎
`
}

exports.groupMenu = (prefix) => {
    return`
╔════المجموعة══════❥︎
╠➤ ${prefix}ceksewa
╠➤ ${prefix}group 
╠➤ ${prefix}afk *alasan*
╠➤ ${prefix}sider *reply chat bot*
╠➤ ${prefix}kickall
╠➤ ${prefix}infogrup
╠➤ ${prefix}promote
╠➤ ${prefix}demote
╠➤ ${prefix}listonline
╠➤ ${prefix}tagall *teks*
╠➤ ${prefix}leave
╠➤ ${prefix}mute
╠➤ ${prefix}unmute
╠➤ ${prefix}kick *reply*
╠➤ ${prefix}add *+62xxxxxx*
╠➤ ${prefix}setgrupname
╠➤ ${prefix}setppgrup
╠➤ ${prefix}setdesc
╠➤ ${prefix}hidetag *teks/reply teks*
╠➤ ${prefix}welcome *enable | disable*
╠➤ ${prefix}antilink *enable | disable*
╠➤ ${prefix}leveling *enable | disable*
╚════════════════❥︎
`
}
exports.downloadMenu = (prefix) => {
    return `
╔════التحميل══════❥︎
╠➤ ${prefix}fb 
╠➤ ${prefix}igdl 
╠➤ ${prefix}igdl2 
╠➤ ${prefix}twitter 
╠➤ ${prefix}tiktok 
╠➤ ${prefix}play 
╠➤ ${prefix}ythd 
╠➤ ${prefix}ytmp3 
╠➤ ${prefix}ytmp4 
╠➤ ${prefix}soundcloud 
╠➤ ${prefix}tiktoknowm 
╠➤ ${prefix}tiktokaudio
╠➤ ${prefix}mediafire 
╠➤ ${prefix}nhentaipdf *code*
╚════════════════❥︎
`
}
exports.rulesBot = (prefix) => {
    return `
-----[ القوانين ]-----

1. السبام لا

2. المكالمات لا


ᴛᴏ ᴜsᴇ ʙᴏᴛ ${prefix}ᴍᴇɴᴜ

ᴏᴡɴᴇʀ ʙᴏᴛ:
رقمي
wa.me/212638701427
 إنستغرامي
 mohammed_xf16
`
}
exports.Menu = (prefix) => {
return `
╔════ɢᴀᴍᴇ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}slot
╠➤ ${prefix}limitgame
╠➤ ${prefix}gelud 
╠➤ ${prefix}tictactoe 
╠➤ ${prefix}siapaaku
╠➤ ${prefix}family100
╠➤ ${prefix}kuismath
╠➤ ${prefix}asahotak
╠➤ ${prefix}tebaklirik
╠➤ ${prefix}tebaklagu
╠➤ ${prefix}tebakkata
╠➤ ${prefix}susunkata
╠➤ ${prefix}kimiakuis
╠➤ ${prefix}caklontong
╠➤ ${prefix}tebakjenaka
╠➤ ${prefix}tebakanime
╠➤ ${prefix}tebaktebakan
╠➤ ${prefix}tebakgambar
╠➤ ${prefix}tebakbendera
╠➤ ${prefix}suit 
╠════ғᴜɴ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}mining
╠➤ ${prefix}togel
╠➤ ${prefix}cekwatak
╠➤ ${prefix}cekmati [nama]
╠➤ ${prefix}wangy [nama]
╠➤ ${prefix}citacita
╠➤ ${prefix}toxic
╠➤ ${prefix}truth
╠➤ ${prefix}dare
╠➤ ${prefix}apakah
╠➤ ${prefix}bisakah
╠➤ ${prefix}kapankah
╠➤ ${prefix}rate
╠➤ ${prefix}jadian
╠➤ ${prefix}cantik
╠➤ ${prefix}ganteng
╠➤ ${prefix}beban
╠➤ ${prefix}babi
╠➤ ${prefix}cekganteng
╠➤ ${prefix}cekcantik
╠════ᴏᴛʜᴇʀ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}brainly 
╠➤ ${prefix}shopee 
╠➤ ${prefix}playstore 
╠➤ ${prefix}ssweb 
╠➤ ${prefix}google 
╠➤ ${prefix}image 
╠➤ ${prefix}pinterest 
╠➤ ${prefix}nulis 
╠➤ ${prefix}iguser 
╠➤ ${prefix}igstalk 
╠➤ ${prefix}githubstalk 
╠➤ ${prefix}tiktokstalk 
╠➤ ${prefix}img2url 
╠➤ ${prefix}ytsearch 
╠════sᴛɪᴄᴋᴇʀ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}dadu
╠➤ ${prefix}doge
╠➤ ${prefix}toimg
╠➤ ${prefix}patrick
╠➤ ${prefix}garwgura
╠➤ ${prefix}ttg 
╠➤ ${prefix}attp 
╠➤ ${prefix}stickeranime
╠➤ ${prefix}semoji 
╠➤ ${prefix}sticker 
╠➤ ${prefix}smeme 
╠➤ ${prefix}swm 
╠➤ ${prefix}take 
╠➤ ${prefix}tovideo 
╠════ᴡɪʙᴜ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}loli
╠➤ ${prefix}manga
╠➤ ${prefix}anime 
╠➤ ${prefix}lolivideo
╠➤ ${prefix}husbu
╠➤ ${prefix}waifu
╠➤ ${prefix}neko
╠➤ ${prefix}kanna
╠➤ ${prefix}sagiri
╠➤ ${prefix}hentai
╠➤ ${prefix}wallnime
╠➤ ${prefix}storyanime
╠➤ ${prefix}kusonime
╠➤ ${prefix}megumin
╠➤ ${prefix}nakanomiku
╠➤ ${prefix}nakanonino
╠➤ ${prefix}nakanoitsuki
╠➤ ${prefix}otakudesu
╠➤ ${prefix}doujindesu
╠➤ ${prefix}otakuongoing
╠➤ ${prefix}nhentai 
╠➤ ${prefix}nekopoi 
╠➤ ${prefix}nekopoi3d
╠➤ ${prefix}nekopoicosplay
╠➤ ${prefix}cosplayanime
╠➤ ${prefix}nekopoisearch
╠════ᴏᴡɴᴇʀ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}bc 
╠➤ ${prefix}term
╠➤ ${prefix}eval
╠➤ ${prefix}reset
╠➤ ${prefix}clearall
╠➤ ${prefix}join 
╠➤ ${prefix}shutdown
╠➤ ${prefix}getquoted
╠➤ ${prefix}addupdate 
╠➤ ${prefix}exif 
╠➤ ${prefix}sewa add/del 
╠➤ ${prefix}premium add 
╠➤ ${prefix}premium del 
╠════ɢʀᴏᴜᴘ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}ceksewa
╠➤ ${prefix}group 
╠➤ ${prefix}afk 
╠➤ ${prefix}sider 
╠➤ ${prefix}kickall
╠➤ ${prefix}infogrup
╠➤ ${prefix}promote
╠➤ ${prefix}demote
╠➤ ${prefix}listonline
╠➤ ${prefix}tagall 
╠➤ ${prefix}leave
╠➤ ${prefix}mute
╠➤ ${prefix}unmute
╠➤ ${prefix}kick 
╠➤ ${prefix}add 
╠➤ ${prefix}setgrupname
╠➤ ${prefix}setppgrup
╠➤ ${prefix}setdesc
╠➤ ${prefix}hidetag 
╠➤ ${prefix}welcome 
╠➤ ${prefix}antilink 
╠➤ ${prefix}leveling 
╠════ᴅᴏᴡɴʟᴏᴀᴅ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}fb 
╠➤ ${prefix}igdl 
╠➤ ${prefix}igdl2 
╠➤ ${prefix}twitter 
╠➤ ${prefix}tiktok 
╠➤ ${prefix}play 
╠➤ ${prefix}ythd 
╠➤ ${prefix}ytmp3 
╠➤ ${prefix}ytmp4 
╠➤ ${prefix}soundcloud 
╠➤ ${prefix}tiktoknowm 
╠➤ ${prefix}tiktokaudio
╠➤ ${prefix}mediafire 
╠➤ ${prefix}nhentaipdf 
╚════════════════❥︎
`
}
exports.infoMenu = (prefix) => {
return `
╔════ɪɴғᴏ-ᴍᴇɴᴜ══════❥︎
╠➤ ${prefix}update
╠➤ ${prefix}level
╠➤ ${prefix}rules
╠➤ ${prefix}profile
╠➤ ${prefix}waktu
╠➤ ${prefix}botstat
╠➤ ${prefix}sewabot
╠➤ ${prefix}listsewa
╠➤ ${prefix}owner
╠➤ ${prefix}ping
╠➤ ${prefix}runtime
╠➤ ${prefix}donasi
╠➤ ${prefix}leaderboard
╠➤ ${prefix}cekpremium
╠➤ ${prefix}listpremium
╠➤ ${prefix}sourcecode
╠➤ ${prefix}bugreport *keluhan*
╚════════════════❥︎

`
} 
